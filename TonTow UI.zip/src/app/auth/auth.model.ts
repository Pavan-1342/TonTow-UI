export  class LoginParam  {
    username!: string;
    password!: string;
  
}

export class User {
    id!: string;
    username!: string;
    password!: string;
    token!: string;
    succeeded!: string;
    Succeeded!: any;
    Errors!: any;
    data: any;
    tonTowRptId : number;
}