export const environment = {
  production: true,
  baseApiUrl:'http://172.16.20.168:8081/api/'
};
